# Independent exact check of a cap certificate (written separately from the audit's checker).
import json, sys
from fractions import Fraction as F
from decimal import Decimal, getcontext
getcontext().prec = 60
d = json.load(open(sys.argv[1]))
v = [(F(x), F(y)) for x, y in d["vertices"]]
N = len(v) - 1
assert v[0] == (1, 0) and v[-1] == (0, 0), "must run from p=(1,0) to e=(0,0)"
assert len(set(v)) == len(v), "vertices must be distinct"
# K = {y >= 0} ∩ closed disc of radius 1 about c = (1/2, -sqrt3/2):
#   (x-1/2)^2 + (y+sqrt3/2)^2 <= 1  <=>  s := x - x^2 - y^2 >= sqrt3 * y  <=>  s >= 0 and s^2 >= 3 y^2  (for y >= 0)
inside = 0
for (x, y) in v:
    s = x - x * x - y * y
    assert y >= 0 and s >= 0 and s * s >= 3 * y * y, f"vertex outside K: {(float(x), float(y))}"
    inside += (y > 0 and s * s > 3 * y * y)
# Strict self-approach inequalities (v_j - v_i).(v_i - v_{i-1}) > 0 for 1 <= i < j <= N.
pairs = 0
worst = None
for i in range(1, N + 1):
    ux, uy = v[i][0] - v[i - 1][0], v[i][1] - v[i - 1][1]
    for j in range(i + 1, N + 1):
        dx, dy = v[j][0] - v[i][0], v[j][1] - v[i][1]
        dot = dx * ux + dy * uy
        assert dot > 0, f"inequality fails or is tight at i={i}, j={j}"
        pairs += 1
        c = float(dot) / ((float(dx) ** 2 + float(dy) ** 2) ** 0.5 * (float(ux) ** 2 + float(uy) ** 2) ** 0.5)
        worst = c if worst is None else min(worst, c)
# The last segment's open interior lies in the interior of K: v_{N-1} is interior (y > 0, strictly in the disc), e is on the boundary.
x, y = v[N - 1]
s = x - x * x - y * y
assert y > 0 and s * s > 3 * y * y and s > 0, "v_{N-1} must be interior to K"
D = lambda a, b: (Decimal(a.numerator) / Decimal(a.denominator)) ** 2 + (Decimal(b.numerator) / Decimal(b.denominator)) ** 2
seg = [D(v[i][0] - v[i - 1][0], v[i][1] - v[i - 1][1]).sqrt() for i in range(1, N + 1)]
lam = sum(seg[:-1]) + 2 * seg[-1]
pi = Decimal("3.14159265358979323846264338327950288419716939937510582097494")
print(f"{N} segments, {pairs} strict inequalities, all {N+1} vertices in K ({inside} strictly inside)")
print(f"smallest normalised margin {worst:.6g}")
print(f"Lambda = {str(lam)[:24]}   pi/3 + Lambda = {str(pi / 3 + lam)[:24]}   2 + pi/3 = {str(2 + pi / 3)[:24]}")
