"""Refine a feasible cap polygon: insert midpoints on all edges except the last (this keeps it
feasible), then re-optimize with the sequential LP."""
import sys, numpy as np
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
from slp import optimize, lam, pairs, cosm
src, tag, k, iters = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
V = np.load(src)
for _ in range(k):
    out = [V[0]]
    for i in range(1, len(V)):
        if i < len(V) - 1:
            out.append((V[i - 1] + V[i]) / 2)
        out.append(V[i])
    V = np.array(out)
N = len(V) - 1; I, J = pairs(N)
print("refined N =", N, "Lambda =", lam(V), "min cos-eta =", cosm(V, I, J, 1e-6).min(), flush=True)
V, ph, cm = optimize(V, 1e-6, iters=iters, rho=0.02, log_every=25)
print("final: phase", ph, "Lambda", lam(V), "min cos-eta", cm)
np.save(f"sub_{tag}.npy", V)
