"""Exact dual certificate for the hull-only problem:
   max per(K)  over convex K with 0 in K, K in the quadrant Q={x,y>=0}, diam K <= 1.
Identity: per(K) = int (h(t)+h(t+pi)) dmu(t) - int g dS_K  for every such K,
so per(K) <= |mu| = 2pi/3 + 4 sin(pi/12), with equality for the trimmed Reuleaux triangle.
Angles in degrees. g = 0 on N = [180,270]; mirror symmetry t <-> 90 - t.
Part 1 checks the breakpoint identities to 55 digits (decimal arithmetic, audit/hp.py);
the identities on the open pieces hold by the closed forms (g+g'' = -1 or 0)."""
import sys, numpy as np
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
import hp
from decimal import Decimal as Dd
from scipy.spatial import ConvexHull
PI = hp.pi(); R = PI/180
S, C = (lambda d: hp.sin(Dd(d)*R)), (lambda d: hp.cos(Dd(d)*R))
t15 = S(15)/C(15); t75 = S(Dd("7.5"))/C(Dd("7.5"))
c1 = (t15 - t75)/hp.sqrt(Dd(3))
A = (1 + c1/4)/C(15); B = -c1/(4*S(15))
# (a, b, g, g') with g' the derivative per radian; on each piece g + g'' is -1 (I, IV) or 0
P = [(-90, -75, lambda d: C(Dd(d) + Dd("82.5"))/C(Dd("7.5")) - 1, lambda d: -S(Dd(d) + Dd("82.5"))/C(Dd("7.5")), -1),
     (-75, -45, lambda d: Dd(0), lambda d: Dd(0), 0),
     (-45, -15, lambda d: c1*S(Dd(d) + 45), lambda d: c1*C(Dd(d) + 45), 0),
     (-15, 15, lambda d: -1 + A*C(d) + B*S(d), lambda d: -A*S(d) + B*C(d), -1),
     (15, 45, lambda d: Dd(0), lambda d: Dd(0), 0)]
atoms = {-75: t75, -45: c1, -15: t75, 15: t15 + c1}
dens = {-90: 0, -75: 1, -45: 1, -15: 0, 15: 1}
ok = True
def chk(name, v):
    global ok
    good = abs(v) < Dd("1e-50"); ok &= good
    print(f"  {name:52s} {'< 1e-50' if good else v}")
print("1. continuity of g, and jump of g' = atom of mu-tilde, at each breakpoint")
chk("g(-90)", P[0][2](-90))
for k in range(1, len(P)):
    a = P[k][0]
    chk(f"g continuous at {a}", P[k][2](a) - P[k-1][2](a))
    chk(f"[g'] at {a} minus atom", P[k][3](a) - P[k-1][3](a) - atoms[a])
chk("g'(45) (smooth mirror at 45)", P[-1][3](45))
print("2. density of mu-tilde minus (g+g'') on each open piece")
for a, b, g, gp, gg in P:
    print(f"  ({a:4d},{b:4d}): {dens[a]} - ({gg}) = {dens[a] - gg}")
    ok &= (dens[a] - gg == 1)
print("3. g >= 0 (sampled)")
for a, b, g, gp, gg in P:
    m = min(float(g(Dd(str(x)))) for x in np.linspace(a, b, 301)); ok &= m > -1e-30
    print(f"  min g on [{a},{b}] = {m:+.3e}")
print("4. total mass of the pair measure mu")
total = 120*R + 2*t75 + c1 + 2*(t15 + c1)
target = 2*PI/3 + 4*S(15)
chk("|mu| - (2pi/3 + 4 sin(pi/12))", total - target)
print(f"  |mu| = {str(total)[:32]}")
print("EXACT PART:", "PASS" if ok else "FAIL")
gf = [(a, b, (lambda g: (lambda x: float(g(Dd(repr(float(x)))))))(g)) for a, b, g, gp, gg in P]
c1f, t15f, t75f, target = float(c1), float(t15), float(t75), float(target)

# ---- numerical test of the identity per K = int w dmu - int g dS_K on random polygons ----
def g_of(t):                                   # t in degrees, any real
    t = (t + 180) % 360 - 180                  # (-180, 180]
    if 180 - 1e-12 <= t % 360 <= 270 + 1e-12 or t < -90: return 0.0
    if t > 45: t = 90 - t
    for a, b, f in gf:
        if a - 1e-12 <= t <= b + 1e-12: return f(t)
    return 0.0
def pair_integral(V):
    h = lambda d: np.max(V @ np.array([np.cos(np.radians(d)), np.sin(np.radians(d))]))
    w = lambda d: h(d) + h(d + 180)
    xs = np.linspace(15, 75, 6001); I1 = np.trapezoid([h(x) for x in xs], np.radians(xs))
    xs = np.linspace(105, 165, 6001); I2 = np.trapezoid([w(x) for x in xs], np.radians(xs))
    return I1 + I2 + t75f*(w(105) + w(165)) + c1f*w(135) + (t15f + c1f)*(h(15) + h(75))
def per_and_S(V):
    H = ConvexHull(V); P = V[H.vertices]; E = np.roll(P, -1, 0) - P
    L = np.linalg.norm(E, axis=1); n = np.degrees(np.arctan2(-E[:, 0], E[:, 1]))   # outer normals (ccw hull)
    return L.sum(), sum(l*g_of(a) for l, a in zip(L, n))
rng = np.random.default_rng(1); bound = target; worst = 0; maxerr = 0
for trial in range(400):
    k = rng.integers(3, 12)
    pts = rng.random((k, 2)) * rng.random() ** 0.3
    V = np.vstack([[0, 0], pts]); V = V[ConvexHull(V).vertices]
    dia = max(np.linalg.norm(a - b) for a in V for b in V); V = V / dia
    per, Sg = per_and_S(V); I = pair_integral(V)
    maxerr = max(maxerr, abs(per - (I - Sg))); worst = max(worst, per)
    assert per <= bound + 1e-12
# the trimmed Reuleaux triangle, as a fine polygon of its boundary (inscribed, so slightly short)
e = lambda d: np.array([np.cos(np.radians(d)), np.sin(np.radians(d))])
Bv, Av = e(75), e(15)
arc = lambda c, a, b, n: [c + e(x) for x in np.linspace(a, b, n)]
V = np.array([[0, 0]] + arc(Bv, -75, -45, 400) + arc(np.zeros(2), 15, 75, 800) + arc(Av, 135, 165, 400))
per, Sg = per_and_S(V); I = pair_integral(V)
print(f"NUMERICAL: identity error on 400 random polygons <= {maxerr:.1e}; largest perimeter {worst:.6f} <= {bound:.10f}")
print(f"  trimmed Reuleaux triangle (inscribed 1600-gon): per = {per:.10f}, slack terms: |mu|-int w dmu = {bound-I:.2e}, int g dS = {Sg:.2e}")
