"""Minimal arbitrary-precision helpers (mpmath is unavailable offline).

Uses Python's decimal module with Taylor series / Newton iterations.
Every routine is cross-checked against `bc -l` in constants.py.
"""
from decimal import Decimal as D, getcontext

getcontext().prec = 60


def pi():
    # Chudnovsky-free: Machin formula pi = 16 atan(1/5) - 4 atan(1/239)
    return 16 * atan_small(D(1) / 5) - 4 * atan_small(D(1) / 239)


def atan_small(x):
    getcontext().prec += 10
    x = D(x)
    s, t, n, x2 = D(0), x, 0, x * x
    while True:
        term = t / (2 * n + 1)
        if abs(term) < D(10) ** (-(getcontext().prec)):
            break
        s += term if n % 2 == 0 else -term
        t *= x2
        n += 1
    getcontext().prec -= 10
    return +s


PI = pi()


def _reduce(x):
    x = D(x)
    twopi = 2 * PI
    k = (x / twopi).to_integral_value()
    return x - k * twopi


def sin(x):
    getcontext().prec += 10
    x = _reduce(x)
    s, t, n = D(0), x, 1
    while abs(t) > D(10) ** (-(getcontext().prec)):
        s += t
        t = -t * x * x / ((n + 1) * (n + 2))
        n += 2
    getcontext().prec -= 10
    return +s


def cos(x):
    getcontext().prec += 10
    x = _reduce(x)
    s, t, n = D(0), D(1), 0
    while abs(t) > D(10) ** (-(getcontext().prec)):
        s += t
        t = -t * x * x / ((n + 1) * (n + 2))
        n += 2
    getcontext().prec -= 10
    return +s


def sqrt(x):
    return D(x).sqrt()


def tan(x):
    return sin(x) / cos(x)


def acos(x):
    # Newton on cos(y) = x, y in [0, pi]
    x = D(x)
    import math
    y = D(repr(math.acos(float(x))))
    for _ in range(8):
        y = y + (cos(y) - x) / sin(y)
    return y


def asin(x):
    x = D(x)
    import math
    y = D(repr(math.asin(float(x))))
    for _ in range(8):
        y = y - (sin(y) - x) / cos(y)
    return y
