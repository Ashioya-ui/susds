"""Maximal multiplicity of a vanishing self-approaching oscillation followed by a one-sided cone.

Periodic polygon with P vertices per period, drift (-1,0) per period (average direction d = 180 deg).
Constraints:  (7.1) between every segment of period 0 and all vertices of the next `K` periods;
              every segment direction t satisfies t.e(180deg) >= 0 and t.e(180deg - Theta) >= 0
              (half-planes w.r.t. far later points in the cone [180-Theta, 180]).
Objective:    length of one period (= multiplicity, since the progress per period is 1).
Scale-free: the height of the oscillation is free.  Compare with the asymmetric zig-zag value
mu_z = sqrt2 (Theta <= 45) or cos+sin (Theta >= 45) and the hull bound 1 + cos Theta.
"""
import numpy as np
from scipy.optimize import minimize
import sys


def build(x, P):
    V = np.vstack([[0.0, 0.0], x.reshape(P - 1, 2), [-1.0, 0.0]])
    return V


def allverts(V, P, K):
    out = [V[:-1] + np.array([-k, 0.0]) for k in range(K + 1)]
    return np.vstack(out + [V[-1:] + np.array([-K, 0.0])])


def length(x, P):
    V = build(x, P)
    return np.sum(np.linalg.norm(np.diff(V, axis=0), axis=1))


def cons(x, P, K, Th):
    V = build(x, P)
    A = allverts(V, P, K)
    out = []
    u1 = np.array([-1.0, 0.0]); u2 = np.array([np.cos(np.pi - Th), np.sin(np.pi - Th)])
    for i in range(1, P + 1):
        d = A[i] - A[i - 1]
        out.append((A[i + 1:] - A[i]) @ d)
        out.append([d @ u1, d @ u2])
    return np.concatenate([np.atleast_1d(np.asarray(o, float)) for o in out])


def solve(Th, P=12, K=3, ns=40, seed=0):
    rng = np.random.default_rng(seed)
    best = (-np.inf, None)
    for k in range(ns):
        # start: noisy staircase / random oscillation with height ~ U(0.2, 2)
        hgt = 0.2 + 2 * rng.random()
        xs = -np.sort(rng.random(P - 1))
        ys = hgt * rng.random(P - 1)
        x0 = np.stack([xs, ys], 1).ravel()
        try:
            res = minimize(lambda x: -length(x, P), x0, method='SLSQP',
                           constraints=[{'type': 'ineq', 'fun': cons, 'args': (P, K, Th)}],
                           options={'maxiter': 3000, 'ftol': 1e-12})
        except Exception:
            continue
        if res.success or True:
            c = cons(res.x, P, K, Th)
            if c.min() > -1e-9 and -res.fun > best[0]:
                best = (-res.fun, res.x)
    return best


def validate(x, P, Th, K=12):
    V = build(x, P)
    A = allverts(V, P, K)
    worst = 1
    for i in range(1, P + 1):
        d = A[i] - A[i - 1]; nd = np.linalg.norm(d)
        if nd < 1e-9: continue
        Z = A[i + 1:] - A[i]; nz = np.linalg.norm(Z, axis=1); ok = nz > 1e-9
        worst = min(worst, np.min(Z[ok] @ d / (nd * nz[ok])))
    return worst


if __name__ == "__main__":
    P = int(sys.argv[1]) if len(sys.argv) > 1 else 12
    for th_deg in [0, 15, 30, 37.5, 45, 60, 75]:
        Th = np.deg2rad(th_deg)
        v, x = solve(Th, P=P, ns=30, seed=int(th_deg * 10) + P)
        muz = np.sqrt(2) if th_deg <= 45 else np.cos(Th) + np.sin(Th)
        wv = validate(x, P, Th) if x is not None else np.nan
        print(f"Theta={th_deg:5.1f}  best periodic polygon mu = {v:.5f}  (zig-zag {muz:.5f}, hull bound {1+np.cos(Th):.5f})"
              f"  validation min cos over 12 periods = {wv:+.1e}", flush=True)
