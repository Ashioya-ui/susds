# Hull-only LP: maximize the perimeter of the circumscribed N-gon of a convex body K with
# 0 in K, K inside the quadrant {x>=0, y>=0}, diam K <= 1.  Variables h_i = h_K(theta_i).
import numpy as np, sys
from scipy.optimize import linprog
from scipy.sparse import lil_matrix

def solve(N):
    th = 2*np.pi*np.arange(N)/N
    D = 2*np.pi/N
    c = -2*np.tan(np.pi/N)*np.ones(N)                    # maximize
    rows, b = [], []
    A = lil_matrix((N//2 + N, N))
    r = 0
    for i in range(N//2):                                 # widths h_i + h_{i+N/2} <= 1
        A[r, i] = 1; A[r, i+N//2] = 1; b.append(1.0); r += 1
    for i in range(N):                                    # convexity: -(h_{i-1}+h_{i+1}-2cos D h_i) <= 0
        A[r, (i-1) % N] = -1; A[r, (i+1) % N] = -1; A[r, i] = 2*np.cos(D); b.append(0.0); r += 1
    bounds = []
    for t in th:
        deg = np.degrees(t)
        if 180 - 1e-9 <= deg <= 270 + 1e-9:
            bounds.append((0, 0))
        else:
            bounds.append((0, None))
    res = linprog(c, A_ub=A.tocsr(), b_ub=np.array(b), bounds=bounds, method="highs")
    return res, th

if __name__ == "__main__":
    exact = 2*np.pi/3 + 4*np.sin(np.pi/12)
    for N in map(int, sys.argv[1:]):
        res, th = solve(N)
        print(f"N={N:5d}  V_N={-res.fun:.9f}  V_N-exact={-res.fun-exact:.3e}  status={res.status}")
