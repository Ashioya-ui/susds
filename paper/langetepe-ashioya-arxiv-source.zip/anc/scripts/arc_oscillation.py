"""Oscillating along the outer arc of the cap K.  Inscribed polygon p=q_0,...,q_{m+1}=e of the outer
arc; on each chord a short straight buffer, then Theta_k-cascade periods of scale R with
Theta_k = angle(d, e - y_k) at the end y_k of the period (bulging to the inner side), then a straight
remainder.  Checks the half-plane criterion (z - x).T(x) >= 0 on dense samples with exact tangents,
containment in K, and compares the length with per conv = 1 + (length of the inscribed polygon)."""
import numpy as np, sys
S3 = np.sqrt(3.0); A0 = np.array([0.5, -S3/2])
def e(a): return np.stack([np.cos(a), np.sin(a)], -1)
def q(w): return (2*np.cos(w + np.pi/3))[..., None]*e(w)            # outer arc, argument w about e
def Ul(p, R): return R*np.stack([np.cos(p)**2/2, np.pi/4 - p/2 + np.sin(2*p)/4], -1)
def Dl(p, R): return R*np.stack([1 - np.sin(p)**2/2, -p/2 + np.sin(2*p)/4], -1)

def build(m=2, R=0.004, cb=3.0, ns=24):
    W = np.radians(30)*np.arange(m + 2)/(m + 1); Q = q(W); Q[-1] = 0.0
    P, T = [], []
    # envelope of everything after chord i: on each later chord j, the strip of height 0.8R on the
    # inner side, from the end of its buffer to its end (vertices of these rectangles), and the q_j
    ENV = []
    for i in range(m + 1):
        pts = []
        for j in range(i + 1, m + 1):
            A, B = Q[j], Q[j + 1]; dj = (B - A)/np.linalg.norm(B - A); nj = np.array([-dj[1], dj[0]])
            st = A + cb*R*dj
            pts += [A, st, st + 0.8*R*nj, B, B + 0.8*R*nj]
        ENV.append(np.array(pts))
    def seg(a, b, k=4, d=None):
        L = np.linalg.norm(b - a)
        if L < 1e-12: return
        d = (b - a)/L if d is None else d
        for t in np.linspace(0, 1, k, endpoint=False): P.append(a + t*(b - a)); T.append(d)
    for i in range(m + 1):
        A, B = Q[i], Q[i + 1]; Lc = np.linalg.norm(B - A); d = (B - A)/Lc; n = np.array([-d[1], d[0]])
        frame = lambda loc, s0: A + (s0 + loc[..., :1])*d + loc[..., 1:]*n
        s0 = cb*R; seg(A, A + s0*d)
        end = Lc - (cb*R if i == m else 0.0)
        while s0 + R <= end - 1e-12:
            y = A + (s0 + R)*d; v = -y
            Th = np.arctan2(d[0]*v[1] - d[1]*v[0], d @ v)        # angle from d toward n
            if i < m and len(ENV[i]):                                  # exact wedge of the later envelope
                Z = ENV[i] - y; ang = np.arctan2(d[0]*Z[:, 1] - d[1]*Z[:, 0], Z @ d)
                Th = max(Th, ang.max())
            Th = min(max(Th, 0.0), np.pi/2 - 1e-9)
            ps = np.linspace(np.pi/2, Th, ns, endpoint=False)
            for pt, tg in zip(frame(Ul(ps, R), s0), e(ps)): P.append(pt); T.append(tg[0]*d + tg[1]*n)
            a0 = frame(Ul(np.array([Th]), R), s0)[0]; b0 = frame(Dl(np.array([Th - np.pi/2]), R), s0)[0]
            seg(a0, b0, 3, d=np.sin(Th)*d - np.cos(Th)*n)
            ph = np.linspace(Th - np.pi/2, 0, ns, endpoint=False)
            for pt, tg in zip(frame(Dl(ph, R), s0), e(ph)): P.append(pt); T.append(tg[0]*d + tg[1]*n)
            s0 += R
        seg(A + s0*d, B)
    P.append(Q[-1]); T.append(T[-1])
    return np.array(P), np.array(T), Q

def check(P, T):
    worst = np.inf
    for s in range(len(P) - 1):
        z = P[s + 1:] - P[s]; nz = np.linalg.norm(z, axis=1); ok = nz > 1e-13
        if ok.any(): worst = min(worst, np.min((z[ok] @ T[s])/nz[ok]))
    x, y = P[:, 0], P[:, 1]
    inK = min(y.min(), (x - x*x - y*y - S3*y).min())
    return worst, inK

if __name__ == "__main__":
    for m, R in [(2, 0.01), (2, 0.004), (5, 0.002)]:
        P, T, Q = build(m=m, R=R)
        worst, inK = check(P, T)
        L = np.sum(np.linalg.norm(np.diff(P, axis=0), axis=1))
        per = 1 + np.sum(np.linalg.norm(np.diff(Q, axis=0), axis=1))
        print(f"m={m} R={R}: samples {len(P)}, min cos(later, T) = {worst:+.2e}, min K-containment = {inK:+.2e}, "
              f"length {L:.5f} (sampled polyline), per conv = {per:.5f}, 1+pi/3 = {1+np.pi/3:.5f}", flush=True)
