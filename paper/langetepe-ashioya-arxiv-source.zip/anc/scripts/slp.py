"""Sequential linear programming for polygons in the cap K (e=(0,0), p=(1,0), corner angle pi/6).
Maximize Lambda(v) = sum_{i<=N} |v_i - v_{i-1}| + |v_N - v_{N-1}|  (the last segment carries the cascade)
subject to  cos angle(v_j - v_i, v_i - v_{i-1}) >= eta  (1 <= i < j <= N)  and  v_i in K.
v_0 = p and v_N = e are fixed. The LP uses G = z.D - eta|z||D| (z = v_j - v_i, D = v_i - v_{i-1}), whose
second-order term is z-increment times D-increment, rows scaled by 1/(|z||D|), and variables scaled by
per-vertex trust radii tau_k = rho * (shorter adjacent edge), so a step changes every cosine by at most
about 4 rho^2 beyond the linear model; phase 2 backs off by that much."""
import numpy as np, scipy.sparse as sps, time
from scipy.optimize import linprog

S3 = np.sqrt(3.0)
HOPT = {'primal_feasibility_tolerance': 1e-10, 'dual_feasibility_tolerance': 1e-10}

def pairs(N):
    I, J = np.triu_indices(N + 1, 1); m = I >= 1
    return I[m], J[m]

def lam(V):
    L = np.linalg.norm(np.diff(V, axis=0), axis=1)
    return L.sum() + L[-1]

def cosm(V, I, J, eta):
    D = np.diff(V, axis=0)[I - 1]; Z = V[J] - V[I]
    return np.einsum('ij,ij->i', Z, D) / (np.linalg.norm(Z, axis=1) * np.linalg.norm(D, axis=1)) - eta

def region(V):
    P = V[1:-1]
    return P[:, 1], P[:, 0] - P[:, 0]**2 - P[:, 1]**2 - S3 * P[:, 1]

def step(V, I, J, eta, rho, phase, back=4.0):
    N = len(V) - 1; n = N - 1
    Dall = np.diff(V, axis=0); L = np.linalg.norm(Dall, axis=1); U = Dall / L[:, None]
    tau = rho * np.minimum(L[:-1], L[1:]); tau2 = np.repeat(tau, 2)
    Z = V[J] - V[I]; D = Dall[I - 1]; nz = np.linalg.norm(Z, axis=1); nd = L[I - 1]
    s = 1.0 / (nz * nd)
    c0 = np.einsum('ij,ij->i', Z, D) * s - eta
    Zh, Dh = Z / nz[:, None], D / nd[:, None]
    gJ = D - eta * nd[:, None] * Zh
    gI = Z - D + eta * nd[:, None] * Zh - eta * nz[:, None] * Dh
    gIm = -Z + eta * nz[:, None] * Dh
    M = len(I); r = np.arange(M); rows, cols, vals = [], [], []
    for idx, G in ((J, gJ), (I, gI), (I - 1, gIm)):
        m = (idx >= 1) & (idx <= N - 1)
        for c in range(2):
            col = 2 * (idx[m] - 1) + c
            rows.append(r[m]); cols.append(col); vals.append(G[m, c] * s[m] * tau2[col])
    A = sps.csr_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(M, 2 * n))
    y, mu = region(V); P = V[1:-1]
    Ry = sps.csr_matrix((np.ones(n), (np.arange(n), 2 * np.arange(n) + 1)), shape=(n, 2 * n))
    gm = np.stack([1 - 2 * P[:, 0], -2 * P[:, 1] - S3], 1)
    Rm = sps.csr_matrix((gm.ravel(), (np.repeat(np.arange(n), 2), np.arange(2 * n))), shape=(n, 2 * n))
    by = y / tau                      # xi_y >= -y/tau
    bm = mu / tau - 2 * tau - 1e-12   # grad.xi >= 2 tau - mu/tau
    w = np.ones(N); w[-1] = 2.0
    Gl = np.zeros_like(V); Gl[1:] += w[:, None] * U; Gl[:-1] -= w[:, None] * U
    dl = Gl[1:-1].ravel() * tau2
    if phase == 1:
        Aub = sps.vstack([sps.hstack([-A, sps.csr_matrix(np.ones((M, 1)))]),
                          sps.hstack([-Ry, sps.csr_matrix((n, 1))]), sps.hstack([-Rm, sps.csr_matrix((n, 1))])]).tocsr()
        bub = np.concatenate([c0, by, bm]); cc = np.zeros(2 * n + 1); cc[-1] = -1.0
        bounds = [(-1, 1)] * (2 * n) + [(None, 1e-6)]
    else:
        Aub = sps.vstack([-A, -Ry, -Rm]).tocsr()
        bub = np.concatenate([c0 - back * rho**2 - 1e-12, by, bm]); cc = -dl
        bounds = [(-1, 1)] * (2 * n)
    res = linprog(cc, A_ub=Aub, b_ub=bub, bounds=bounds, method='highs', options=HOPT)
    if res.status != 0:
        return None
    W = V.copy(); W[1:-1] += (res.x[:2 * n] * tau2).reshape(n, 2)
    W[1:-1, 1] = np.maximum(W[1:-1, 1], 0.0)
    return W

def merit(V, I, J, eta):
    y, mu = region(V)
    return cosm(V, I, J, eta).min(), min(y.min(), mu.min())

def optimize(V, eta, iters=200, rho=0.05, verbose=True, rho_max=0.3, log_every=10, rho_min=1e-6):
    N = len(V) - 1; I, J = pairs(N); t0 = time.time()
    cm, rm = merit(V, I, J, eta)
    phase = 1 if (cm < 0 or rm < 0) else 2
    best = lam(V)
    for it in range(iters):
        W = step(V, I, J, eta, rho, phase)
        if W is None:
            rho *= 0.5
        else:
            cw, rw = merit(W, I, J, eta)
            if phase == 1:
                if min(cw, rw * 1e6) > min(cm, rm * 1e6) and rw >= min(rm, 0) - 1e-16:
                    V, cm, rm = W, cw, rw; rho = min(rho * 1.4, rho_max)
                    if cm >= 0 and rm >= 0: phase = 2; best = lam(V)
                else:
                    rho *= 0.5
            else:
                lw = lam(W)
                if cw >= 0 and rw >= 0 and lw >= best:
                    V, best, cm, rm = W, lw, cw, rw; rho = min(rho * 1.4, rho_max)
                else:
                    rho *= 0.5
        if verbose and (it % log_every == 0 or it == iters - 1):
            print(f"  it {it:4d} ph {phase} Lambda {lam(V):.9f} min cos-eta {cm:+.2e} region {rm:+.1e} rho {rho:.1e} ({time.time()-t0:.0f}s)", flush=True)
        if rho < rho_min: break
    return V, phase, cm
