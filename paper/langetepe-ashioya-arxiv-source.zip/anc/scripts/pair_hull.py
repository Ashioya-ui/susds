#!/usr/bin/env python3
"""Largest perimeter of conv{0, z_1..z_n} when all |z_i| <= 1 and every pair satisfies
|z_i - z_j| <= max(|z_i|, |z_j|)  (the order-free consequence of self-approach, a = 0).
Radius order by index: |z_1| <= ... <= |z_n| <= 1 and 2 z_i.z_j >= |z_i|^2 for i < j."""
import numpy as np, sys, time
from scipy.optimize import minimize
from scipy.spatial import ConvexHull
HL = 1 + 2*np.pi/3

def per_and_grad(x):
    Z = np.vstack([[0.0, 0.0], x.reshape(-1, 2)])
    try: h = ConvexHull(Z).vertices
    except Exception: return 0.0, np.zeros_like(x)
    P = Z[h]; nxt = np.roll(P, -1, 0); prv = np.roll(P, 1, 0)
    dn = np.linalg.norm(nxt - P, axis=1); dp = np.linalg.norm(P - prv, axis=1)
    g = np.zeros_like(Z); g[h] = (P - nxt)/dn[:, None] + (P - prv)/dp[:, None]
    return dn.sum(), g[1:].ravel()

def solve(x0, n):
    iu = np.triu_indices(n, 1)
    def cons(x):
        Z = x.reshape(-1, 2); r2 = (Z**2).sum(1); G = Z @ Z.T
        return np.concatenate([(2*G - r2[:, None])[iu], np.diff(r2), [1 - r2[-1]]])
    def obj(x):
        p, g = per_and_grad(x); return -p, -g
    res = minimize(obj, x0, jac=True, method="SLSQP", constraints=[{"type": "ineq", "fun": cons}],
                   options={"maxiter": 400, "ftol": 1e-12})
    x = res.x; c = cons(x)
    return per_and_grad(x)[0], c.min(), x

def half_lens(n):
    k = n//2; th = np.linspace(0, np.pi/3, k + 1)[1:]                 # arc about e=(1,0) from a
    A = np.stack([1 - np.cos(th), np.sin(th)], -1)
    ph = np.linspace(np.pi/3, 0, n - k + 1)[1:]
    return np.vstack([A, np.stack([np.cos(ph), np.sin(ph)], -1)])

if __name__ == "__main__":
    n = int(sys.argv[1]); runs = int(sys.argv[2]); budget = float(sys.argv[3]); rng = np.random.default_rng(int(sys.argv[4]) if len(sys.argv) > 4 else 1)
    t0 = time.time(); best = (0, None); vals = []
    hl = half_lens(n); p0, c0, _ = solve(hl.ravel(), n)
    print(f"n={n}: half-lens start -> {p0:.6f} (min constraint {c0:+.1e});  1 + 2pi/3 = {HL:.6f}", flush=True)
    for r in range(runs):
        if time.time() - t0 > budget: break
        kind = r % 4
        if kind == 0:      # random cloud in a wedge
            rad = np.sort(rng.random(n))**0.7; ang = rng.uniform(-np.pi/4, np.pi/4, n); Z = rad[:, None]*np.stack([np.cos(ang), np.sin(ang)], -1)
        elif kind == 1:    # both sides: alternate
            rad = np.sort(rng.random(n)); ang = np.where(np.arange(n) % 2 == 0, 1, -1)*rng.uniform(0.2, 0.7, n)*(1 - 0.6*rad); Z = rad[:, None]*np.stack([np.cos(ang), np.sin(ang)], -1)
        elif kind == 2:    # perturbed half-lens
            Z = hl + 0.05*rng.standard_normal(hl.shape); Z = Z[np.argsort((Z**2).sum(1))]
        else:              # trimmed-Reuleaux-like: two side chains and a far arc
            k = n//3; t = np.linspace(0.15, 1, k)
            up = t[:, None]*np.stack([np.cos(np.radians(75) - 0.3*t), np.sin(np.radians(75) - 0.3*t)], -1)
            lo = t[:, None]*np.stack([np.cos(np.radians(15) + 0.3*t), np.sin(np.radians(15) + 0.3*t)], -1)*rng.uniform(0.3, 1.0)
            ph = np.radians(np.linspace(20, 70, n - 2*k)); far = np.stack([np.cos(ph), np.sin(ph)], -1)
            Z = np.vstack([up, lo, far]) + 0.02*rng.standard_normal((n, 2)); Z = Z[np.argsort((Z**2).sum(1))]
        try: p, c, x = solve(Z.ravel(), n)
        except Exception as ex: continue
        if c < -1e-7: continue
        vals.append(p)
        if p > best[0]: best = (p, x.copy()); print(f"  run {r} kind {kind}: {p:.6f} (min constraint {c:+.1e})", flush=True)
    vals = np.array(vals)
    print(f"n={n}: {len(vals)} feasible runs, best {best[0]:.6f}, exceed half-lens limit by {best[0] - HL:+.6f}; runs above {HL:.4f}: {(vals > HL + 1e-9).sum()}")
    if best[1] is not None:
        Z = best[1].reshape(-1, 2); f = Z[-1]/np.linalg.norm(Z[-1]); Rm = np.array([[f[0], f[1]], [-f[1], f[0]]]); W = Z @ Rm.T
        np.save(f"best_pair_n{n}.npy", W); print("  best config (far point on the x-axis), radius / angle deg:")
        print("  " + "  ".join(f"({np.hypot(*w):.3f},{np.degrees(np.arctan2(w[1], w[0])):+.1f})" for w in W))
