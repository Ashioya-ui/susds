"""Periodic polygons for one-sided oscillations, seeded from the Theta-cascade (osc.py frame:
one period from (0,0) to (-1,0), later far points in the cone [180-Theta, 180])."""
import sys, numpy as np
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
from osc import build, length, cons, validate
from scipy.optimize import minimize

def U(p):  return np.stack([np.cos(p)**2/2, np.pi/4 - p/2 + np.sin(2*p)/4], -1)
def D(p):  return np.stack([1 - np.sin(p)**2/2, -p/2 + np.sin(2*p)/4], -1)

def seed(Th, P):
    mU = (P - 1)//2; mD = P - 1 - mU
    ps = np.pi/2 - np.arange(1, mU+1)*(np.pi/2 - Th)/mU
    ph = Th - np.pi/2 + np.arange(0, mD)*(np.pi/2 - Th)/mD
    V = np.vstack([U(ps), D(ph)])
    V[:, 0] *= -1                      # mirror: progress to the left
    return V.ravel()

def run(Th, P, K=3):
    x0 = seed(Th, P)
    res = minimize(lambda x: -length(x, P), x0, method='SLSQP',
                   constraints=[{'type': 'ineq', 'fun': cons, 'args': (P, K, Th)}],
                   options={'maxiter': 4000, 'ftol': 1e-14})
    return length(x0, P), -res.fun, cons(res.x, P, K, Th).min(), validate(res.x, P, Th), res.x

if __name__ == "__main__":
    import json
    out = {}
    for deg in [float(a) for a in sys.argv[2].split(",")]:
        for P in [int(a) for a in sys.argv[1].split(",")]:
            Th = np.radians(deg)
            l0, mu, cmin, val, x = run(Th, P)
            out[f"{deg}_{P}"] = [mu, val, x.tolist()]
            print(f"Theta={deg:5.1f} P={P:3d}: seed length {l0:.5f} -> mu {mu:.6f}   bound {1+np.cos(Th):.6f}  "
                  f"gap {1+np.cos(Th)-mu:.2e}  min constraint {cmin:+.1e}  validation(12 periods) {val:+.1e}", flush=True)
    json.dump(out, open(f"osc_seeded_{sys.argv[1].replace(',','-')}_{sys.argv[2].replace(',','-')}.json", "w"))
