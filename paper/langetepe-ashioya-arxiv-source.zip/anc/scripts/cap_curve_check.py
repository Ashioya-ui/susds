#!/usr/bin/env python3
"""Independent check of the curve of the cap theorem (kappa = 1 + pi/3), built from the statement in the
paper and not from the earlier scripts.  Frame of the class section: e = 0, a = (1, 0).
Checks, on dense samples of the exact curve:
  (1) self-approach in its defining form: for every sample z, the distances |x - z| from the earlier
      samples x are nonincreasing in time (no tangents used);
  (2) containment of the part after p in the cap K;
  (3) the exact length, sum of l_i + R sum cos(Theta_ik), against per(Pi) = 1 + sum l_i and 1 + pi/3;
  (4) diameter one of the whole curve (arc about e from a to p, then the cap curve)."""
import numpy as np, sys

def e(t): return np.stack([np.cos(t), np.sin(t)], -1)
def U(psi, R): return R*np.stack([0.5*np.cos(psi)**2, np.pi/4 - psi/2 + 0.25*np.sin(2*psi)], -1)
def D(phi, R): return R*np.stack([1 - 0.5*np.sin(phi)**2, -phi/2 + 0.25*np.sin(2*phi)], -1)

def cap_curve(m, R, ns=14, rng=None):
    th = np.pi/3 + np.arange(m + 2)*np.pi/(6*(m + 1))
    q = (2*np.cos(th))[:, None]*e(th); q[-1] = 0.0
    ell = np.linalg.norm(np.diff(q, axis=0), axis=1)
    d = np.diff(q, axis=0)/ell[:, None]
    a = np.array([1.0, 0.0])
    n = np.stack([-d[:, 1], d[:, 0]], -1)                      # left normal
    assert all((a - q[i]) @ n[i] > 0 for i in range(m + 1))    # the side of a
    pts, length, cosum, thetas = [], 0.0, 0.0, []
    for i in range(m + 1):
        # vertices of E_i: later buffers and rectangles of height R
        V = []
        for j in range(i + 1, m + 1):
            V += [q[j], q[j] + 4*R*d[j], q[j] + 4*R*d[j] + R*n[j], q[j] + ell[j]*d[j], q[j] + ell[j]*d[j] + R*n[j]]
        V = np.array(V) if V else None
        loc = lambda z, s0: q[i] + (s0 + z[..., :1])*d[i] + z[..., 1:]*n[i]
        pts.append(q[i][None]); s0 = 4*R
        end = ell[i] - (4*R if i == m else 0.0)
        while s0 + R <= end + 1e-15:
            y = q[i] + (s0 + R)*d[i]
            if V is None: Th = 0.0
            else:
                Z = V - y
                ang = np.arctan2(d[i, 0]*Z[:, 1] - d[i, 1]*Z[:, 0], Z @ d[i])
                assert ang.min() >= -1e-12, ang.min()
                Th = float(ang.max())
            assert 0.0 <= Th < np.pi/2
            thetas.append(Th)
            psi = np.linspace(np.pi/2, Th, ns)
            pts.append(loc(U(psi, R), s0))
            if Th > 0:
                c0, c1 = U(np.array([Th]), R)[0], D(np.array([Th - np.pi/2]), R)[0]
                t = np.linspace(0, 1, 5)[1:-1, None]
                pts.append(loc(c0 + t*(c1 - c0), s0))
            phi = np.linspace(Th - np.pi/2, 0, ns)
            pts.append(loc(D(phi, R), s0))
            cosum += R*np.cos(Th); s0 += R
        pts.append((q[i] + s0*d[i])[None]); pts.append(q[i + 1][None])
    P = np.concatenate(pts)
    keep = np.r_[True, np.linalg.norm(np.diff(P, axis=0), axis=1) > 1e-14]
    return P[keep], q, ell, float(ell.sum() + cosum), np.array(thetas)

def sc_violation(P):
    """largest increase of |P_i - P_k| over consecutive earlier i, i+1 < k (0 if self-approaching)"""
    worst = 0.0
    for k in range(2, len(P)):
        dist = np.linalg.norm(P[:k] - P[k], axis=1)
        inc = np.max(dist[1:] - dist[:-1])
        if inc > worst: worst = inc
    return worst

if __name__ == "__main__":
    a = np.array([1.0, 0.0]); s3 = np.sqrt(3.0)
    for m, R in [(1, 0.01), (2, 0.004), (3, 0.002), (6, 0.001)]:
        P, q, ell, L, Th = cap_curve(m, R)
        arc = e(np.linspace(0, np.pi/3, 400))[:-1]
        C = np.concatenate([arc, P])
        x, y = P[:, 0], P[:, 1]
        inK = min((y - s3*x).min(), x.min(), (1 - np.linalg.norm(P - a, axis=1)).min())
        viol = sc_violation(C)
        diam = np.linalg.norm(C - a, axis=1).max()
        print(f"m={m} R={R}: samples {len(C)}, periods {len(Th)}, max cut angle {np.degrees(Th.max()):.2f} deg, "
              f"SC violation {viol:.1e}, K-containment margin {inK:+.1e}, max dist from a {diam:.12f}\n"
              f"      length in K = {L:.6f}; per(Pi) = {1 + ell.sum():.6f}; 1 + pi/3 = {1 + np.pi/3:.6f}; "
              f"whole curve {np.pi/3 + L:.6f} vs 1 + 2pi/3 = {1 + 2*np.pi/3:.6f}, 2 + pi/3 = {2 + np.pi/3:.6f}", flush=True)
