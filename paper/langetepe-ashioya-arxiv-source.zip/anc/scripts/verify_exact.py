"""Exact certificate for a polygon in the cap K (frame e=(0,0), p=(1,0), K = {y>=0} cap B(c,1),
c = (1/2, -sqrt3/2)).

Steps:
 1. load float vertices, scale about e by (1 - delta) and prepend the segment p -> (1-delta)p
    (keeps (7.1): homogeneity + the new segment points straight at e along the chord, and every
    later vertex has x <= 1-delta);
 2. convert every coordinate to an exact rational (Fraction of the binary float), clip y at 0;
 3. check (7.1) EXACTLY for all 1 <= i < j <= N  (Lemma 7.1 of the paper);
 4. check v in K EXACTLY:  y >= 0,  s := x - x^2 - y^2 >= 0  and  s^2 >= 3 y^2;
 5. report the smallest normalised margin cos angle(v_j - v_i, v_i - v_{i-1}) (in floating point) and
    Lambda = sum |v_i - v_{i-1}| + |v_N - v_{N-1}| to 40 digits (decimal).
"""
import sys
import numpy as np
from fractions import Fraction as Fr
from decimal import Decimal, getcontext

getcontext().prec = 50


def certify(V, delta=Fr(1, 10 ** 9), verbose=True):
    V = np.asarray(V, float)
    assert np.allclose(V[0], [1, 0]) and np.allclose(V[-1], [0, 0])
    Q = [(Fr(1), Fr(0))]
    lam = 1 - delta
    for x, y in V[1:-1]:
        fx, fy = Fr(float(x)) * lam, Fr(float(y)) * lam
        if fy < 0:
            fy = Fr(0)
        Q.append((fx, fy))
    Q.insert(1, (lam, Fr(0)))      # the prepended point (1-delta) p   (p itself is Q[0])
    Q.append((Fr(0), Fr(0)))
    N = len(Q) - 1
    # 3. exact (7.1)
    bad = []
    for i in range(1, N):
        dx, dy = Q[i][0] - Q[i - 1][0], Q[i][1] - Q[i - 1][1]
        for j in range(i + 1, N + 1):
            g = (Q[j][0] - Q[i][0]) * dx + (Q[j][1] - Q[i][1]) * dy
            if g < 0:
                bad.append((i, j, float(g)))
    # 4. exact region
    badK = []
    for k, (x, y) in enumerate(Q):
        s = x - x * x - y * y
        if y < 0 or s < 0 or s * s < 3 * y * y:
            badK.append(k)
    # 5. margins and length
    F = np.array([[float(a), float(b)] for a, b in Q])
    D = np.diff(F, axis=0); L = np.linalg.norm(D, axis=1)
    worst = 1.0
    for i in range(1, N):
        if L[i - 1] == 0: continue
        Z = F[i + 1:] - F[i]; nz = np.linalg.norm(Z, axis=1); ok = nz > 0
        if ok.any():
            worst = min(worst, float(np.min(Z[ok] @ D[i - 1] / (nz[ok] * L[i - 1]))))
    lam_dec = Decimal(0)
    for i in range(1, N + 1):
        dx = Q[i][0] - Q[i - 1][0]; dy = Q[i][1] - Q[i - 1][1]
        s = Decimal(dx.numerator) / Decimal(dx.denominator)
        t = Decimal(dy.numerator) / Decimal(dy.denominator)
        seg = (s * s + t * t).sqrt()
        lam_dec += seg * (2 if i == N else 1)
    if verbose:
        print(f"N = {N} segments; exact (7.1) violations: {len(bad)}; exact region violations: {len(badK)}")
        print(f"smallest normalised (7.1) margin (cos): {worst:.3e}")
        print(f"Lambda = {lam_dec}")
        print(f"shortest segment {L.min():.3e}; last segment {L[-1]:.6f}; max y {F[:,1].max():.5f}")
    return Q, bad, badK, worst, lam_dec


if __name__ == "__main__":
    V = np.load(sys.argv[1])
    certify(V)
