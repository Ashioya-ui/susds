# The Theta-cascade: per period, a cycloid arc U (tangent 90 deg -> Theta, radius R sin psi),
# a straight piece S of length R sin(Theta) in direction Theta-90 deg, a cycloid arc D
# (tangent Theta-90 -> 0, radius -R sin psi), then a 90-degree corner back to U.
# Progress direction d = +x; far later points lie in directions [0, Theta].
import numpy as np

def e(a): return np.stack([np.cos(a), np.sin(a)], -1)

def period(Th, R=1.0, n=400):
    """Points and unit tangents of one period starting at the origin (bottom corner)."""
    pts, tan = [], []
    # U: psi from pi/2 down to Th; U(psi) = R*(cos^2 psi/2, pi/4 - psi/2 + sin(2 psi)/4)
    psi = np.linspace(np.pi/2, Th, n)
    U = R*np.stack([np.cos(psi)**2/2, np.pi/4 - psi/2 + np.sin(2*psi)/4], -1)
    pts.append(U); tan.append(e(psi))
    # S: straight, direction Th - pi/2, length R sin Th
    if Th > 0:
        t = np.linspace(0, R*np.sin(Th), n)[1:]
        S = U[-1] + t[:, None]*e(np.array(Th - np.pi/2))
        pts.append(S); tan.append(np.repeat(e(np.array(Th - np.pi/2))[None], len(t), 0))
        D0 = S[-1]
    else:
        D0 = U[-1]
    # D: psi from Th - pi/2 up to 0; D(psi) = D0 - R*[F(psi) - F(Th - pi/2)], F = (sin^2/2, psi/2 - sin(2psi)/4)
    F = lambda p: np.stack([np.sin(p)**2/2, p/2 - np.sin(2*p)/4], -1)
    psi = np.linspace(Th - np.pi/2, 0, n)[1:]
    D = D0 - R*(F(psi) - F(np.array(Th - np.pi/2)))
    pts.append(D); tan.append(e(psi))
    return np.vstack(pts), np.vstack(tan)

def check(Th, periods=6, n=400):
    P, T = period(Th, n=n)
    L = np.sum(np.linalg.norm(np.diff(P, axis=0), axis=1))
    shift = P[-1] - P[0]
    allP = np.vstack([P + k*shift for k in range(periods)])
    allT = np.vstack([T for _ in range(periods)])
    worst = np.inf
    for i in range(len(P)):                          # every point of the first period
        z = allP[i+1:] - allP[i]
        nz = np.linalg.norm(z, axis=1); ok = nz > 1e-12
        worst = min(worst, np.min((z[ok] @ allT[i]) / nz[ok]))
    # far later points in directions [0, Th]: tangent must have nonnegative product with e(0) and e(Th)
    far = min(np.min(allT @ e(np.array(0.0))), np.min(allT @ e(np.array(Th))))
    return L, shift, worst, far

if __name__ == "__main__":
    for deg in [0, 10, 20, 30, 45, 60, 75, 85]:
        Th = np.radians(deg)
        L, shift, worst, far = check(Th)
        print(f"Theta={deg:4.1f}  length/period={L:.6f}  progress={shift[0]:.6f}  height drift={shift[1]:+.1e}"
              f"  multiplicity={L/shift[0]:.6f}  1+cos={1+np.cos(Th):.6f}  min cos(later,T)={worst:+.2e}  far={far:+.2e}")
