"""Figure of the certified polygon (rational vertices from the JSON certificate), cap frame e=(0,0), p=(1,0)."""
import json, sys, numpy as np, matplotlib
from fractions import Fraction as Fr
matplotlib.use("Agg"); import matplotlib.pyplot as plt
V = np.array([[float(Fr(x)), float(Fr(y))] for x, y in json.load(open(sys.argv[1]))["vertices"]])
L = np.linalg.norm(np.diff(V, axis=0), axis=1)
osc = V[V[:, 1] < 0.012]
print(f"N={len(V)-1}; v_(N-1)={V[-2]}; last segment {L[-1]:.4f}; length before it {L[:-1].sum():.4f}; "
      f"chord oscillation for x in [{V[1:-1][V[1:-1,1] < 0.012][:,0].min():.3f}, 1], max height there {V[1:-1][V[1:-1,0] > 0.92][:,1].max():.4f}")
arg = np.arctan2(V[1:-1, 1], V[1:-1, 0]); print("argument decreases", int(np.sum(np.diff(arg) < 0)), "times")
plt.rcParams.update({"font.size": 8, "font.family": "serif"})
fig, ax = plt.subplots(1, 2, figsize=(6.4, 2.0), gridspec_kw={"width_ratios": [1.6, 1]})
w = np.linspace(0, np.pi/6, 300); arc = (2*np.cos(w + np.pi/3))[:, None]*np.stack([np.cos(w), np.sin(w)], 1)
for a in ax:
    a.fill(np.r_[arc[:, 0], 0.0], np.r_[arc[:, 1], 0.0], color="#e8eef5", lw=0)
    a.plot(arc[:, 0], arc[:, 1], color="0.45", lw=0.7); a.plot([0, 1], [0, 0], color="0.45", lw=0.7)
    a.plot(V[:-1, 0], V[:-1, 1], color="#1f4e79", lw=0.6)
    a.plot(V[-2:, 0], V[-2:, 1], color="#b5402a", lw=1.8)
    a.set_aspect("equal"); a.axis("off")
x0, x1, y0, y1 = 0.88, 1.005, -0.004, 0.06
ax[0].plot([x0, x1, x1, x0, x0], [y0, y0, y1, y1, y0], color="0.3", lw=0.6, ls="--")
ax[0].text(1.0, -0.035, "$p$", ha="center"); ax[0].text(0.0, -0.035, "$e$", ha="center")
ax[0].set_xlim(-0.03, 1.03); ax[0].set_ylim(-0.05, 0.15)
ax[1].plot(V[:-1, 0], V[:-1, 1], "o", color="#1f4e79", ms=0.9)
ax[1].set_xlim(x0, x1); ax[1].set_ylim(y0, y1)
fig.tight_layout(); fig.savefig("fig_certificate.pdf")
