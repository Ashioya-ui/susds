"""Figure: a cut cascade with changing cut angles, and the oscillation along the outer arc of the cap."""
import sys, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
from arc_oscillation import build, Ul, Dl, q
plt.rcParams.update({"font.size": 8, "font.family": "serif"})
fig, ax = plt.subplots(2, 1, figsize=(6.4, 3.3), gridspec_kw={"height_ratios": [1.15, 1]})
# left: four periods with cut angles 0, 20, 40, 60 degrees
a = ax[0]; x0 = 0.0
for k, deg in enumerate([0, 20, 40, 60]):
    Th = np.radians(deg)
    u = Ul(np.linspace(np.pi/2, Th, 200), 1.0); dd = Dl(np.linspace(Th - np.pi/2, 0, 200), 1.0)
    a.plot(u[:, 0] + x0, u[:, 1], color="#1f4e79", lw=1.2)
    a.plot([u[-1, 0] + x0, dd[0, 0] + x0], [u[-1, 1], dd[0, 1]], color="#b5402a", lw=1.2)
    a.plot(dd[:, 0] + x0, dd[:, 1], color="#1f4e79", lw=1.2)
    a.text(x0 + 0.5, -0.17, rf"$\Theta_{k}={deg}^\circ$", ha="center")
    if deg == 0:
        uu = Ul(np.array([0.0]), 1.0)[0]
        a.plot([x0, x0 + 1], [0, 0], color="0.6", lw=0.5)
    x0 += 1.0
a.plot([0, x0], [0, 0], color="0.6", lw=0.5)
y = np.array([x0, 0.0]); Th = np.radians(60)
for t in [0, Th]:
    a.plot([y[0], y[0] + 0.55*np.cos(t)], [y[1], y[1] + 0.55*np.sin(t)], color="0.35", lw=0.7, ls="--")
a.text(y[0] + 0.42, 0.18, r"$y+V_{\Theta}$", fontsize=7)
a.set_aspect("equal"); a.axis("off"); a.set_xlim(-0.05, x0 + 0.75); a.set_ylim(-0.25, 0.85)
a.set_title("cut cascade: arcs $U$, $D$ (blue), chords $S$ (red)", fontsize=8)
# bottom: the cap in the frame e=(0,0), p=(1,0), with m = 2 and an exaggerated scale R = 0.02
b = ax[1]
w = np.linspace(0, np.pi/6, 300); arc = q(w)
b.fill(np.r_[arc[:, 0], 0.0], np.r_[arc[:, 1], 0.0], color="#e8eef5", lw=0)
b.plot(arc[:, 0], arc[:, 1], color="0.45", lw=0.8); b.plot([0, 1], [0, 0], color="0.45", lw=0.8)
P, T, Q = build(m=2, R=0.02, ns=40)
b.plot(P[:, 0], P[:, 1], color="#1f4e79", lw=0.7)
b.plot(Q[:, 0], Q[:, 1], "o", color="#b5402a", ms=2.5)
b.text(1.0, -0.035, "$p$", ha="center"); b.text(0.0, -0.035, "$e$", ha="center")
b.text(0.5, 0.03, "$K$", color="0.35", ha="center")
b.set_aspect("equal"); b.axis("off"); b.set_xlim(-0.03, 1.03); b.set_ylim(-0.05, 0.15)
b.set_title("cut cascades along the chords of an inscribed polygon of the outer arc ($m=2$, $R=0.02$)", fontsize=8)
fig.tight_layout(); fig.savefig("fig_cut.pdf"); print("ok")
