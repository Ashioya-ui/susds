import numpy as np
from arc_oscillation import build, Ul, Dl, e
# (a) variable-Theta cascade with a random sequence Theta_k (constant scale), exact tangents
rng = np.random.default_rng(7)
P, T = [], []
x0 = 0.0
for k in range(40):
    Th = rng.uniform(0, np.radians(85))
    ps = np.linspace(np.pi/2, Th, 30, endpoint=False)
    for a, b in zip(Ul(ps, 1.0), e(ps)): P.append(a + [x0, 0]); T.append(b)
    a0 = Ul(np.array([Th]), 1.0)[0] + [x0, 0]; b0 = Dl(np.array([Th - np.pi/2]), 1.0)[0] + [x0, 0]
    for t in np.linspace(0, 1, 5, endpoint=False): P.append(a0 + t*(b0 - a0)); T.append(e(np.array(Th - np.pi/2)))
    ph = np.linspace(Th - np.pi/2, 0, 30, endpoint=False)
    for a, b in zip(Dl(ph, 1.0), e(ph)): P.append(a + [x0, 0]); T.append(b)
    x0 += 1.0
P.append(np.array([x0, 0.0])); T.append(np.array([1.0, 0.0])); P, T = np.array(P), np.array(T)
w = min(np.min(((P[s+1:] - P[s]) @ T[s])/np.maximum(np.linalg.norm(P[s+1:] - P[s], axis=1), 1e-300)) for s in range(len(P) - 1))
L = np.sum(np.linalg.norm(np.diff(P, axis=0), axis=1))
print(f"(a) 40 periods, random Theta_k in [0,85 deg]: min cos(later, T) = {w:+.2e}; length/progress = {L/x0:.6f}")
# (b) length of the arc oscillation as R -> 0 (no pair check), and per conv of the inscribed polygon
for m in [5, 11, 23]:
    out = []
    for R in [2e-3, 5e-4, 1.25e-4]:
        P, T, Q = build(m=m, R=R, ns=16)
        out.append(np.sum(np.linalg.norm(np.diff(P, axis=0), axis=1)))
    per = 1 + np.sum(np.linalg.norm(np.diff(Q, axis=0), axis=1))
    print(f"(b) m={m:2d}: length at R=2e-3, 5e-4, 1.25e-4: " + ", ".join(f"{x:.5f}" for x in out) + f";  per conv = {per:.5f}")
print(f"    1 + pi/3 = {1 + np.pi/3:.5f}")
