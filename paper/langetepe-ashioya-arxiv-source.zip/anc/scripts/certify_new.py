"""Exact certificate for a cap polygon (frame e=(0,0), p=(1,0), a=(1/2,-sqrt3/2), K={y>=0} cap B(a,1)).
Rationalizes as in audit/verify_exact.py (scale about e by 1-1e-9 and prepend p -> (1-1e-9)p), then checks
in exact rational arithmetic: every vertex in K; (7.1) STRICTLY for all pairs; v_{N-1} interior to K.
Writes the JSON certificate and prints Lambda to 50 digits."""
import sys, json, numpy as np
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
from verify_exact import certify
from fractions import Fraction as Fr
V = np.load(sys.argv[1]); out = sys.argv[2]
Q, bad, badK, worst, lam = certify(V, verbose=False)
N = len(Q) - 1
strict_bad = 0
for i in range(1, N):
    dx, dy = Q[i][0] - Q[i-1][0], Q[i][1] - Q[i-1][1]
    xi, yi = Q[i]
    for j in range(i + 1, N + 1):
        if (Q[j][0] - xi) * dx + (Q[j][1] - yi) * dy <= 0:
            strict_bad += 1
inK = all(y >= 0 and (x - x*x - y*y) >= 0 and (x - x*x - y*y)**2 >= 3*y*y for x, y in Q)
x, y = Q[N - 1]; s = x - x*x - y*y
interior = y > 0 and s > 0 and s*s > 3*y*y
print(f"N = {N} segments, {N*(N-1)//2} inequalities (7.1): strict violations {strict_bad}; all vertices in K: {inK}; "
      f"v_(N-1) interior: {interior}; smallest cos = {worst:.3e}")
print(f"Lambda = {lam}")
json.dump({"frame": "e=(0,0), p=(1,0), K={y>=0} cap B((1/2,-sqrt3/2),1)",
           "vertices": [[str(a), str(b)] for a, b in Q], "N_segments": N,
           "min_normalised_margin": worst, "Lambda": str(lam)[:42]}, open(out, "w"), indent=0)
